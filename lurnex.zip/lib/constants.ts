export const navItems = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Courses", href: "/courses" },
  { label: "Learn with Us", href: "/learn-with-us" },
  { label: "Locations", href: "/locations" },
  { label: "Success Stories", href: "/success-stories" },
  { label: "Blog", href: "/blog" }
];

export const courses = [
  {
    title: "JEE Preparation",
    href: "/courses/jee",
    image: "/assets/images/jee.png",
    alt: "JEE Preparation program at lumex",
    description: "Build a strong foundation for India's top engineering colleges.",
    features: ["Live Classes", "Mock Tests", "Performance Tracking"],
    badge: "Popular"
  },
  {
    title: "NEET Preparation",
    href: "/courses/neet",
    image: "/assets/images/neet.png",
    alt: "NEET Preparation program at lumex",
    description: "Focused preparation for your medical career dreams.",
    features: ["Expert Faculty", "NCERT-Based Learning", "Regular Assessments"]
  },
  {
    title: "IB Diploma",
    href: "/courses/ib",
    image: "/assets/images/ib.png",
    alt: "IB Diploma program at lumex",
    description: "International curriculum with global exposure.",
    features: ["Experienced Mentors", "Project Guidance", "University Counselling"]
  },
  {
    title: "SAT Prep",
    href: "/courses/sat",
    image: "/assets/images/sat.png",
    alt: "SAT Preparation program at lumex",
    description: "Comprehensive coaching for global university admissions.",
    features: ["Concept Clarity", "Adaptive Practice", "Personalised Mentoring"]
  }
];

export const programs = ["SAT", "JEE", "NEET", "IB", "IGCSE", "CBSE"];

export const testimonials = [
  {
    quote: "lumex's personalised approach helped me improve my SAT score by 350 points. The mentors are incredible!",
    name: "Aisha Khan",
    location: "Dubai, UAE",
    avatar: "/avatars/avatar-1.jpg"
  },
  {
    quote: "The faculty explains concepts so clearly. The mock tests and feedback really helped me crack JEE.",
    name: "Rohan Mehta",
    location: "New Delhi, India",
    avatar: "/avatars/avatar-2.jpg"
  },
  {
    quote: "Flexible timings and one-to-one mentoring made learning so easy from the US. Highly recommend lumex!",
    name: "Sarah Williams",
    location: "New York, USA",
    avatar: "/avatars/avatar-3.jpg"
  }
];

export const faqs = [
  ["What curriculum do you specialize in?", "We support JEE, NEET, SAT, IB, IGCSE, CBSE and personalised academic mentoring based on each learner's goals."],
  ["How are tutors selected?", "Tutors are selected for subject expertise, teaching experience, communication and their ability to support individual learning goals."],
  ["Can I get a trial class?", "Yes. You can request a trial or counselling session through the form on this page and our team can guide you through the next step."],
  ["How does flexible scheduling work?", "Sessions can be arranged around school, time-zone and learner availability, subject to tutor availability."],
  ["Do you provide study material?", "Learning plans can include structured resources, practice material, mock tests and feedback relevant to the selected program."],
  ["Which countries do you support?", "lumex is designed for learners globally. Availability and scheduling depend on the program and tutor."],
];
