type ApiOptions = Omit<RequestInit, "body"> & { body?: unknown };

const apiBase = process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, "");

/** Calls the configured Lurnex backend. Set NEXT_PUBLIC_API_URL in production. */
export async function api<T>(path: string, options: ApiOptions = {}): Promise<T> {
  if (!apiBase) throw new Error("The learning API is not configured yet.");
  const token = typeof window === "undefined" ? null : localStorage.getItem("lumex_token");
  const response = await fetch(`${apiBase}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });
  if (!response.ok) throw new Error((await response.json().catch(() => null))?.message || "Unable to complete your request.");
  return response.json() as Promise<T>;
}

export const learningApi = {
  registerStudent: (body: unknown) => api<{ token?: string }>("/auth/register-student", { method: "POST", body }),
  getBlogs: () => api<Array<{ slug: string; title: string; excerpt?: string; coverImage?: string; createdAt?: string }>>("/blogs"),
  getBlog: (slug: string) => api(`/blogs/${slug}`),
  createBlog: (body: unknown) => api("/blogs", { method: "POST", body }),
  startAssessment: (body: unknown) => api<{ attemptId: string; token?: string; questions?: unknown[] }>("/assessments/public/start", { method: "POST", body }),
  submitAssessment: (attemptId: string, body: unknown) => api(`/assessments/public/${attemptId}/submit`, { method: "POST", body }),
  bookAssessmentSlot: (attemptId: string, body: { preferredSlot: string }) => api(`/assessments/public/${attemptId}/book-slot`, { method: "POST", body }),
};
