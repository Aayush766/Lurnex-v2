export const siteUrl = "https://www.lumex.com";

export const defaultDescription =
  "Learn with lumex through expert-led online courses, personalised tutoring and global academic programs including JEE, NEET, SAT, IB and more.";
