import { courses, faqs } from "./constants";

export function getOrganizationSchema() {
  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "EducationalOrganization",
        "@id": "https://www.lumex.com/#organization",
        name: "lumex",
        slogan: "Learn. Grow. Excel.",
        url: "https://www.lumex.com",
        description: "Global online learning and personalised academic tutoring."
      },
      {
        "@type": "WebSite",
        "@id": "https://www.lumex.com/#website",
        url: "https://www.lumex.com",
        name: "lumex",
        publisher: { "@id": "https://www.lumex.com/#organization" }
      },
      ...courses.map((course) => ({
        "@type": "Course",
        name: course.title,
        description: course.description,
        provider: {
          "@type": "EducationalOrganization",
          name: "lumex",
          sameAs: "https://www.lumex.com"
        },
        url: `https://www.lumex.com${course.href}`
      })),
      {
        "@type": "FAQPage",
        mainEntity: faqs.map(([question, answer]) => ({
          "@type": "Question",
          name: question,
          acceptedAnswer: { "@type": "Answer", text: answer }
        }))
      }
    ]
  };
}
