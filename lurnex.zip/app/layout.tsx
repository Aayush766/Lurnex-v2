import type { Metadata } from "next";
import "./globals.css";
import { defaultDescription, siteUrl } from "@/lib/seo";
import { WhatsAppWidget } from "@/components/ui/WhatsAppWidget";
import { ScrollRegistrationModal } from "@/components/ui/ScrollRegistrationModal";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "lumex | Online Learning, JEE, NEET, SAT & Global Academic Programs",
    template: "%s | lumex"
  },
  description: defaultDescription,
  keywords: [
    "online learning", "online tutoring", "JEE preparation", "NEET preparation",
    "SAT preparation", "IB Diploma", "global tutoring", "one-to-one tutoring",
    "personalised learning", "online classes", "exam preparation",
    "international students", "academic mentoring"
  ],
  authors: [{ name: "lumex" }],
  creator: "lumex",
  publisher: "lumex",
  alternates: { canonical: "/" },
  robots: { index: true, follow: true },
  openGraph: {
    type: "website",
    url: siteUrl,
    title: "lumex | Online Learning, JEE, NEET, SAT & Global Academic Programs",
    description: defaultDescription,
    siteName: "lumex"
  },
  twitter: {
    card: "summary_large_image",
    title: "lumex | Online Learning & Global Academic Programs",
    description: defaultDescription
  },
  icons: { icon: "/icon.svg" }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body><Header />{children}<Footer /><ScrollRegistrationModal /><WhatsAppWidget /></body>
    </html>
  );
}
