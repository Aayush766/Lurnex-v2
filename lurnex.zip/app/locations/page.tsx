import Link from "next/link";
import { locations } from "@/lib/locations";

export default function Page() {
  return (
    <main className="min-h-screen bg-[#F4FAFF]">
      <div className="container-shell py-20">
        <Link href="/" className="text-sm font-bold text-[#087FF5]">← Back to lumex</Link>
        <h1 className="mt-8 text-4xl font-extrabold text-[#071B3A]">Locations</h1>
        <p className="mt-4 max-w-2xl text-slate-600">Live, personalised tutoring with scheduling that works around your family’s local time zone.</p>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{locations.map((location) => <Link href={`/locations/${location.slug}`} key={location.slug} className="rounded-2xl bg-white p-5 shadow-sm transition hover:-translate-y-0.5"><span className="text-2xl">{location.flag}</span><h2 className="mt-2 font-bold text-[#071B3A]">Online tutoring in {location.name}</h2><p className="mt-2 text-sm text-slate-600">{location.cities.join(" · ")}</p></Link>)}</div>
      </div>
    </main>
  );
}
