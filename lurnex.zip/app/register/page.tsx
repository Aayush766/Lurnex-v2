import Link from "next/link";
import { RegisterForm } from "@/components/forms/RegisterForm";

export default function Page() {
  return (
    <main className="min-h-screen bg-[#F4FAFF]">
      <div className="container-shell py-20">
        <Link href="/" className="text-sm font-bold text-[#087FF5]">← Back to lumex</Link>
        <h1 className="mt-8 text-4xl font-extrabold text-[#071B3A]">Register</h1>
        <p className="mt-4 max-w-2xl text-slate-600">Tell us about your learning goals and an academic advisor will help you choose the right path.</p>
        <RegisterForm />
      </div>
    </main>
  );
}
