import Link from "next/link";
import { BlogIndex } from "@/components/blog/BlogIndex";

export default function Page() {
  return (
    <main className="min-h-screen bg-[#F4FAFF]">
      <div className="container-shell py-20">
        <Link href="/" className="text-sm font-bold text-[#087FF5]">← Back to lumex</Link>
        <h1 className="mt-8 text-4xl font-extrabold text-[#071B3A]">Blog</h1>
        <p className="mt-4 max-w-2xl text-slate-600">Practical academic guidance for students and families navigating school, entrance exams and global curricula.</p>
        <BlogIndex />
      </div>
    </main>
  );
}
