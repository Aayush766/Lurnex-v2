import type { Metadata } from "next";
import { ProgramPage } from "@/components/courses/ProgramPage";
import { siteUrl } from "@/lib/seo";

export const metadata: Metadata = {
  title: "NEET UG Online Coaching & Preparation | lumex",
  description: "Prepare for NEET UG with personalised online Physics, Chemistry and Biology tutoring, topic-focused practice and an individual study plan from lumex.",
  alternates: { canonical: "/courses/neet" },
  openGraph: { title: "NEET UG Preparation | lumex", description: "Personalised NEET UG preparation with guided subject learning and regular practice.", url: `${siteUrl}/courses/neet`, type: "website" },
};
export default function CoursePage() { return <ProgramPage slug="neet" />; }
