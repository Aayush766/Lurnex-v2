import Link from "next/link";
import Image from "next/image";
import {
  ArrowRight,
  Bell,
  BookOpen,
  BookOpenCheck,
  CalendarDays,
  Check,
  ChevronRight,
  Download,
  FileText,
  GraduationCap,
  HelpCircle,
  Lightbulb,
  Link2,
  MessageCircle,
  NotebookTabs,
  PlayCircle,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  Trophy,
  Users,
} from "lucide-react";
// The stylesheet is handled by Next.js at build time; TypeScript does not
// have a declaration for this side-effect import in this project.
// @ts-expect-error -- CSS side-effect imports are resolved by Next.js.
import "./jee-page.css";

const leftNav = [
  "JEE Overview",
  "JEE Main",
  "JEE Advanced",
  "IIT JEE Coaching",
  "IITs & NITs",
  "BITSAT",
  "Study Material",
  "Previous Year Papers",
  "Mock Tests",
  "Important Books",
  "Preparation Strategy",
  "Results & Cutoffs",
  "FAQs",
];

const quickLinks = [
  "JEE Main Overview",
  "JEE Main Syllabus",
  "JEE Main Question Papers",
  "JEE Main Cutoff",
  "JEE Main Rank Predictor",
  "JEE Main Important Books",
  "JEE Advanced Overview",
  "JEE Advanced Syllabus",
  "JEE Advanced Question Papers",
  "JEE Advanced Cutoff",
  "JEE Advanced Important Books",
  "JEE Preparation Tips",
];

const mainResources = [
  { title: "Overview", text: "Exam pattern, eligibility, important dates", icon: BookOpen },
  { title: "Syllabus", text: "Topic-wise syllabus with weightage", icon: NotebookTabs },
  { title: "Study Material", text: "Notes, DPPs, formula sheets", icon: FileText },
  { title: "Previous Year Papers", text: "10+ years papers with solutions", icon: BookOpenCheck },
  { title: "Mock Tests", text: "Chapter-wise & full-length", icon: ShieldCheck },
  { title: "Important Books", text: "Recommended by experts", icon: BookOpen },
  { title: "Cutoff & Colleges", text: "Opening & closing ranks", icon: Trophy },
  { title: "Preparation Tips", text: "Expert strategies & time plan", icon: Lightbulb },
];

const advancedResources = [
  { title: "Overview", text: "Exam pattern & eligibility", icon: BookOpen },
  { title: "Syllabus", text: "Topic-wise advanced syllabus", icon: NotebookTabs },
  { title: "Previous Year Papers", text: "Papers with detailed solutions", icon: FileText },
  { title: "Study Material", text: "Advanced notes & problem sets", icon: BookOpenCheck },
  { title: "Mock Tests", text: "Full-length & topic tests", icon: ShieldCheck },
  { title: "Important Books", text: "Must-read books list", icon: BookOpen },
  { title: "Rank Predictor", text: "Estimate your rank", icon: Users },
  { title: "Preparation Strategy", text: "Subject-wise planning", icon: Target },
];

const downloads = [
  ["JEE Main Syllabus 2025", "PDF · 2.1 MB"],
  ["JEE Main Previous Papers", "PDF · 12.5 MB"],
  ["JEE Main Formula Sheet", "PDF · 1.8 MB"],
  ["JEE Advanced Syllabus", "PDF · 2.4 MB"],
  ["JEE Preparation Strategy", "PDF · 1.6 MB"],
];

const morePrograms = [
  { title: "IIT JEE", text: "Complete guide for IIT JEE aspirants", icon: GraduationCap },
  { title: "IIT JEE Coaching", text: "Live & online coaching by expert faculty", icon: Users },
  { title: "BITSAT", text: "Preparation resources for BITSAT", icon: CalendarDays },
];

function ResourceCard({
  item,
}: {
  item: { title: string; text: string; icon: React.ElementType };
}) {
  const Icon = item.icon;

  return (
    <Link href="#" className="jee-resource-card">
      <span className="jee-resource-icon">
        <Icon size={18} />
      </span>
      <span className="jee-resource-copy">
        <b>{item.title}</b>
        <small>{item.text}</small>
      </span>
    </Link>
  );
}

function SectionHeading({
  icon: Icon,
  title,
  subtitle,
  action,
}: {
  icon: React.ElementType;
  title: string;
  subtitle: string;
  action?: string;
}) {
  return (
    <div className="jee-section-heading">
      <div className="jee-heading-left">
        <span className="jee-section-icon">
          <Icon size={17} />
        </span>
        <div>
          <h2>{title}</h2>
          <p>{subtitle}</p>
        </div>
      </div>

      {action && (
        <Link href="#" className="jee-view-link">
          {action}
          <ArrowRight size={14} />
        </Link>
      )}
    </div>
  );
}

export function JEEPage() {
  return (
    <main className="jee-page">
      <header className="jee-topbar">
        <Link href="/" className="jee-brand">
          <span className="jee-brand-mark">
            <BookOpen size={22} />
          </span>
          <span>
            <strong>LUMEX</strong>
            <small>Learn. Grow. Excel.</small>
          </span>
        </Link>

        <nav className="jee-main-nav" aria-label="Main navigation">
          {["Home", "Courses", "JEE", "NEET", "IB", "IGCSE", "SAT", "CBSE", "Foundation", "Resources", "Results", "About Us"].map(
            (item) => (
              <Link
                key={item}
                href="#"
                className={item === "JEE" ? "active" : ""}
              >
                {item}
              </Link>
            ),
          )}
        </nav>

        <div className="jee-header-actions">
          <div className="jee-search">
            <Search size={16} />
            <span>Search for courses, notes, tests...</span>
          </div>
          <a className="jee-phone" href="tel:18001234567">
            <span>☎</span> 1800-123-4567
          </a>
          <Link href="/register?program=jee" className="jee-expert-button">
            Talk to an Expert
            <ArrowRight size={15} />
          </Link>
        </div>
      </header>

      <div className="jee-shell">
        <div className="jee-breadcrumb">
          <Link href="/">Home</Link>
          <ChevronRight size={13} />
          <span>JEE</span>
        </div>

        <div className="jee-layout">
          <aside className="jee-left-sidebar">
            <div className="jee-side-menu">
              <h2>
                <GraduationCap size={19} />
                JEE
              </h2>

              <nav>
                {leftNav.map((item, index) => (
                  <Link
                    key={item}
                    href="#"
                    className={index === 1 ? "selected" : ""}
                  >
                    <ChevronRight size={13} />
                    {item}
                  </Link>
                ))}
              </nav>
            </div>

            <div className="jee-free-card">
              <span className="jee-free-badge">FREE</span>
              <h3>JEE Study Material</h3>
              <p>Chapter-wise notes, PYQs, tests & more</p>
              <Link href="#">
                Download Now
                <ArrowRight size={14} />
              </Link>
              <div className="jee-book-stack" aria-hidden="true">
                <span />
                <span />
                <span />
                <span />
              </div>
            </div>

            <div className="jee-guidance-card">
              <div className="jee-guide-avatar">
                <Users size={27} />
              </div>
              <h3>Need Guidance?</h3>
              <p>Talk to our JEE experts for personalised support.</p>
              <Link href="/register?program=jee">
                Talk to an Expert
                <ArrowRight size={14} />
              </Link>
              <small>Available 10 AM – 7 PM</small>
            </div>
          </aside>

          <div className="jee-main">
            <section className="jee-hero">
              <div className="jee-hero-bg-shape shape-one" />
              <div className="jee-hero-bg-shape shape-two" />

              <div className="jee-hero-copy">
                <span className="jee-eyebrow">INDIA&apos;S LEADING JEE PREPARATION PROGRAM</span>
                <h1>
                  JEE Mains &amp; Advanced
                  <span>Dream. Prepare. Achieve.</span>
                </h1>
                <p>
                  Comprehensive study material, expert faculty and personalised
                  guidance for your path to IITs.
                </p>

                <div className="jee-hero-actions">
                  <Link href="/register?program=jee" className="jee-primary">
                    Start Your JEE Journey
                    <ArrowRight size={17} />
                  </Link>
                  <Link href="#" className="jee-secondary">
                    <Download size={16} />
                    Download Brochure
                  </Link>
                </div>
              </div>

              <div className="jee-hero-student">
                <Image
                  src="/assets/images/jee-boy.png"
                  alt="Lurnex JEE student"
                  width={1371}
                  height={1148}
                  priority
                  sizes="(max-width: 720px) 45vw, 310px"
                />
              </div>

              <div className="jee-hero-note">
                Better
                <br />
                Students
                <br />
                Brighter
                <br />
                Futures
              </div>

              <div className="jee-hero-stats">
                <div>
                  <span className="stat-icon blue"><Trophy size={19} /></span>
                  <div>
                    <b>1000+</b>
                    <small>IIT Selections</small>
                  </div>
                </div>
                <div>
                  <span className="stat-icon orange"><GraduationCap size={19} /></span>
                  <div>
                    <b>15+</b>
                    <small>Years of Excellence</small>
                  </div>
                </div>
                <div>
                  <span className="stat-icon green"><Sparkles size={19} /></span>
                  <div>
                    <b>4.8/5</b>
                    <small>Student Satisfaction</small>
                  </div>
                </div>
              </div>
            </section>

            <section className="jee-exam-row">
              <div className="jee-exam-panel">
                <div className="jee-exam-heading">
                  <div>
                    <h2>
                      <CalendarDays size={18} />
                      JEE Exam Dates (2025)
                    </h2>
                    <Link href="#">
                      View Official Notices
                      <ArrowRight size={13} />
                    </Link>
                  </div>
                </div>

                <div className="jee-exam-cards">
                  <div className="jee-exam-card">
                    <span className="exam-icon blue">
                      <GraduationCap size={19} />
                    </span>
                    <div>
                      <b>JEE Main 2025</b>
                      <p>Session 1: <strong>22 Jan – 31 Jan 2025</strong></p>
                      <p>Session 2: <strong>01 Apr – 08 Apr 2025</strong></p>
                    </div>
                  </div>

                  <div className="jee-exam-card">
                    <span className="exam-icon orange">
                      <GraduationCap size={19} />
                    </span>
                    <div>
                      <b>JEE Advanced 2025</b>
                      <p>Exam Date: <strong>18 May 2025</strong></p>
                    </div>
                    <Link href="#">
                      View Details <ArrowRight size={13} />
                    </Link>
                  </div>
                </div>
              </div>

              <div className="jee-update-card">
                <span className="update-icon">
                  <Bell size={20} />
                </span>
                <div>
                  <h3>Stay Updated</h3>
                  <p>Get notified about exam dates, form releases, results and more.</p>
                  <form className="jee-email-form">
                    <input type="email" placeholder="Enter your email address" />
                    <button type="button" aria-label="Subscribe">
                      <ArrowRight size={17} />
                    </button>
                  </form>
                </div>
              </div>
            </section>

            <section className="jee-content-card">
              <SectionHeading
                icon={BookOpen}
                title="Explore JEE Main Resources"
                subtitle="Everything you need to crack JEE Main – study material, tests, syllabus and more."
                action="View All Resources"
              />
              <div className="jee-resource-grid">
                {mainResources.map((item) => (
                  <ResourceCard key={item.title} item={item} />
                ))}
              </div>
            </section>

            <section className="jee-content-card">
              <SectionHeading
                icon={GraduationCap}
                title="Explore JEE Advanced Resources"
                subtitle="In-depth resources for JEE Advanced preparation."
                action="View All Resources"
              />
              <div className="jee-resource-grid">
                {advancedResources.map((item) => (
                  <ResourceCard key={item.title} item={item} />
                ))}
              </div>
            </section>

            <section className="jee-content-card jee-more-programs">
              <SectionHeading
                icon={Sparkles}
                title="More JEE Programs"
                subtitle="Explore other engineering entrance exams and coaching programs."
              />
              <div className="jee-more-grid">
                {morePrograms.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link href="#" key={item.title} className="jee-more-card">
                      <span>
                        <Icon size={20} />
                      </span>
                      <div>
                        <b>{item.title}</b>
                        <small>{item.text}</small>
                        <strong>
                          Explore {item.title} <ArrowRight size={13} />
                        </strong>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </section>
          </div>

          <aside className="jee-right-sidebar">
            <section className="jee-quick-card">
              <h2>
                <Link2 size={17} />
                Quick Links
              </h2>

              {quickLinks.map((item) => (
                <Link href="#" key={item}>
                  <span>{item}</span>
                  <ChevronRight size={13} />
                </Link>
              ))}

              <Link href="#" className="jee-rail-button">
                View All JEE Resources
                <ArrowRight size={14} />
              </Link>
            </section>

            <section className="jee-mentor-card">
              <div>
                <span className="mentor-spark">
                  <Lightbulb size={17} />
                </span>
                <h2>Personalised<br />JEE Mentorship</h2>
                <p>Get a customised study plan, doubt support and regular performance analysis.</p>
                <Link href="/register?program=jee">
                  Talk to a Mentor
                  <ArrowRight size={14} />
                </Link>
              </div>

              <Image
                src="/assets/images/jee-girl.png"
                alt="Lurnex JEE mentor"
                width={1305}
                height={1205}
                sizes="180px"
              />
            </section>

            <section className="jee-download-card">
              <h2>
                <Download size={17} />
                Useful Downloads
              </h2>

              {downloads.map(([title, meta]) => (
                <Link href="#" key={title}>
                  <span className="pdf-icon">PDF</span>
                  <span>
                    <b>{title}</b>
                    <small>{meta}</small>
                  </span>
                  <Download size={14} />
                </Link>
              ))}

              <Link href="#" className="jee-rail-button">
                View All Downloads
                <ArrowRight size={14} />
              </Link>
            </section>

            <section className="jee-doubt-card">
              <span className="doubt-icon">
                <MessageCircle size={18} />
              </span>
              <div>
                <h2>Have a Doubt?</h2>
                <p>Get instant answers from our subject experts.</p>
                <Link href="/contact">
                  Ask a Question
                  <ArrowRight size={14} />
                </Link>
              </div>
              <span className="jee-chat-bubble">
                <MessageCircle size={21} />
              </span>
            </section>
          </aside>
        </div>
      </div>
    </main>
  );
}
