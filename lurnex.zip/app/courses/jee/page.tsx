import type { Metadata } from "next";
import { siteUrl } from "@/lib/seo";

export const metadata: Metadata = {
  title: "JEE Main & Advanced Online Coaching | Lurnex",
  description:
    "Prepare for JEE Main and JEE Advanced with personalised online Physics, Chemistry and Mathematics tutoring, structured practice and academic guidance from Lurnex.",
  alternates: { canonical: "/courses/jee" },
  openGraph: {
    title: "JEE Main & Advanced Preparation | Lurnex",
    description:
      "Personalised online JEE preparation with subject tutoring, focused practice and learning guidance.",
    url: `${siteUrl}/courses/jee`,
    type: "website",
  },
};

export default function CoursePage() {
  return (
    <main>
      <h1>JEE Main &amp; Advanced Online Coaching</h1>
      <p>
        Prepare for JEE Main and JEE Advanced with personalised online tutoring,
        structured practice, and academic guidance from Lurnex.
      </p>
    </main>
  );
}
