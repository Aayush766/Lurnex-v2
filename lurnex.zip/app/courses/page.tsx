"use client";

import Link from "next/link";
import { useMemo, useState, type ReactNode } from "react";
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Globe2,
  GraduationCap,
  Languages,
  LayoutGrid,
  Search,
  Sparkles,
  Target,
  Trophy,
  Users,
  MonitorPlay,
  Clock3,
} from "lucide-react";

import "./page.css";

type Category =
  | "all"
  | "school"
  | "competitive"
  | "international";

type Course = {
  code: string;
  title: string;
  category: string;
  type: Category;
  description: string;
  image: string;
  href: string;
  icon: ReactNode;
  badge?: string;
  classes: string;
  mode: string;
  duration: string;
  subjects: string[];
  features: string[];
};

const courses: Course[] = [
  {
    code: "IB",
    title: "IB Diploma",
    category: "International",
    type: "international",
    description:
      "Globally recognized curriculum for future-ready learners.",
    image: "/assets/images/ibdiploma.png",
    href: "/courses/ib",
    icon: <Globe2 size={17} />,
    badge: "Global",
    classes: "Grades 11–12",
    mode: "Live + Recorded",
    duration: "2 Years",
    subjects: ["Sciences", "Maths", "Languages"],
    features: [
      "Critical Thinking",
      "Research Skills",
      "University Preparation",
    ],
  },

  {
    code: "IGCSE",
    title: "IGCSE Curriculum",
    category: "International",
    type: "international",
    description:
      "Flexible international curriculum with strong academic foundations.",
    image: "/assets/images/igcse.png",
    href: "/courses/igcse",
    icon: <BookOpen size={17} />,
    badge: "Popular",
    classes: "Grades 9–10",
    mode: "Live + Recorded",
    duration: "2 Years",
    subjects: ["Maths", "Science", "English"],
    features: [
      "Wide Subject Choice",
      "Global Readiness",
      "University Pathways",
    ],
  },

  {
    code: "AP",
    title: "Advanced Placement",
    category: "International",
    type: "international",
    description:
      "University-level learning for ambitious high school students.",
    image: "/assets/images/ap.png",
    href: "/courses/ap",
    icon: <GraduationCap size={17} />,
    badge: "Advanced",
    classes: "Grades 10–12",
    mode: "Live + Recorded",
    duration: "1 Year",
    subjects: ["Calculus", "Physics", "Chemistry"],
    features: [
      "Advanced Academics",
      "College Credit",
      "University Preparation",
    ],
  },

  {
    code: "SAT",
    title: "SAT Prep",
    category: "Competitive",
    type: "competitive",
    description:
      "Focused preparation for global university admissions.",
    image: "/assets/images/sat.png",
    href: "/courses/sat",
    icon: <Target size={17} />,
    badge: "Popular",
    classes: "Grades 9–12",
    mode: "Live + Practice",
    duration: "3–6 Months",
    subjects: ["Reading", "Writing", "Maths"],
    features: [
      "Expert Faculty",
      "Mock Tests",
      "Score Tracking",
    ],
  },

  {
    code: "CBSE",
    title: "CBSE Curriculum",
    category: "School",
    type: "school",
    description:
      "Structured learning focused on concepts and academic excellence.",
    image: "/assets/images/cbse.png",
    href: "/courses/cbse",
    icon: <BookOpen size={17} />,
    badge: "School",
    classes: "Classes 6–12",
    mode: "Live + Recorded",
    duration: "Full Year",
    subjects: ["Maths", "Science", "English"],
    features: [
      "Concept Clarity",
      "Regular Tests",
      "Performance Tracking",
    ],
  },

  {
    code: "NEET",
    title: "NEET Foundations",
    category: "Competitive",
    type: "competitive",
    description:
      "Build a strong foundation for medical entrance preparation.",
    image: "/assets/images/neet.png",
    href: "/courses/neet",
    icon: <Target size={17} />,
    badge: "Medical",
    classes: "Classes 9–12",
    mode: "Live + Tests",
    duration: "1–4 Years",
    subjects: ["Physics", "Chemistry", "Biology"],
    features: [
      "Expert Faculty",
      "Test Series",
      "Mentorship",
    ],
  },

  {
    code: "FOUNDATION",
    title: "Foundation Courses",
    category: "School",
    type: "school",
    description:
      "Strong fundamentals for students from Classes 6 to 10.",
    image: "/assets/images/foundation.png",
    href: "/courses/foundation",
    icon: <Sparkles size={17} />,
    badge: "Classes 6–10",
    classes: "Classes 6–10",
    mode: "Live + Recorded",
    duration: "Full Year",
    subjects: ["Maths", "Science", "English"],
    features: [
      "Concept Learning",
      "Interactive Classes",
      "Assessments",
    ],
  },

  {
    code: "JEE",
    title: "JEE Mains & Advanced",
    category: "Competitive",
    type: "competitive",
    description:
      "Complete engineering preparation for JEE Mains and Advanced.",
    image: "/assets/images/jee.png",
    href: "/courses/jee",
    icon: <Trophy size={17} />,
    badge: "Engineering",
    classes: "Classes 11–12",
    mode: "Live + Tests",
    duration: "1–2 Years",
    subjects: ["Physics", "Chemistry", "Maths"],
    features: [
      "Expert Mentorship",
      "Mock Tests",
      "JEE Analysis",
    ],
  },
];

const filters = [
  {
    id: "all" as Category,
    label: "All Programs",
    icon: <LayoutGrid size={16} />,
  },
  {
    id: "school" as Category,
    label: "School",
    icon: <BookOpen size={16} />,
  },
  {
    id: "competitive" as Category,
    label: "Competitive",
    icon: <Trophy size={16} />,
  },
  {
    id: "international" as Category,
    label: "International",
    icon: <Globe2 size={16} />,
  },
];

const languages = [
  {
    name: "English",
    flag: "🇬🇧",
    subtitle: "Public Speaking",
    text: "Confident communication for academic and global opportunities.",
  },
  {
    name: "Hindi",
    flag: "🇮🇳",
    subtitle: "Academic Mastery",
    text: "Build clarity, confidence and strong expression.",
  },
  {
    name: "French",
    flag: "🇫🇷",
    subtitle: "Global Fluency",
    text: "Practical communication for international exposure.",
  },
];

export default function Courses() {
  const [filter, setFilter] = useState<Category>("all");
  const [search, setSearch] = useState("");

  const visibleCourses = useMemo(() => {
    const q = search.toLowerCase().trim();

    return courses.filter((course) => {
      const categoryMatch =
        filter === "all" || course.type === filter;

      const searchMatch =
        !q ||
        [
          course.code,
          course.title,
          course.category,
          course.description,
          course.classes,
          ...course.subjects,
          ...course.features,
        ]
          .join(" ")
          .toLowerCase()
          .includes(q);

      return categoryMatch && searchMatch;
    });
  }, [filter, search]);

  return (
    <>
      <main className="courses-page">

        {/* HERO */}

        <section className="courses-hero">
          <div className="courses-container">

            <div className="hero-content">

              <div className="hero-copy">

                <div className="hero-eyebrow">
                  <Sparkles size={13} />
                  EXPLORE LUMEX PROGRAMS
                </div>

                <h1>
                  Find Your{" "}
                  <span>Perfect Course</span>
                </h1>

                <p>
                  School curriculum, competitive exams and
                  international programs — all in one place.
                </p>

                <div className="hero-points">
                  <span>
                    <CheckCircle2 size={14} />
                    Expert Faculty
                  </span>

                  <span>
                    <CheckCircle2 size={14} />
                    Personalized Learning
                  </span>

                  <span>
                    <CheckCircle2 size={14} />
                    Global Programs
                  </span>
                </div>

              </div>

              <div className="hero-search-area">

                <div className="hero-search">

                  <Search size={18} />

                  <input
                    value={search}
                    onChange={(e) =>
                      setSearch(e.target.value)
                    }
                    placeholder="Search JEE, NEET, IB, SAT..."
                  />

                  {search && (
                    <button
                      onClick={() => setSearch("")}
                      type="button"
                    >
                      ×
                    </button>
                  )}

                </div>

                <div className="hero-stat">

                  <strong>08</strong>

                  <div>
                    <span>Learning</span>
                    <small>Programs</small>
                  </div>

                </div>

              </div>

            </div>

            {/* FILTER */}

            <div className="filter-bar">

              <div className="filter-label">
                <span>EXPLORE BY</span>
                <strong>Program Type</strong>
              </div>

              <div className="filter-buttons">

                {filters.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setFilter(item.id)}
                    className={
                      filter === item.id
                        ? "active"
                        : ""
                    }
                  >
                    {item.icon}
                    {item.label}
                  </button>
                ))}

              </div>

              <Link
                href="/courses/languages"
                className="language-filter"
              >
                <Languages size={15} />
                Languages
              </Link>

            </div>

          </div>
        </section>


        {/* COURSE SECTION */}

        <section className="courses-section">

          <div className="courses-container">

            <div className="section-header">

              <div>
                <span className="section-kicker">
                  OUR COURSES
                </span>

                <h2>
                  Learn. Prepare.{" "}
                  <span>Achieve.</span>
                </h2>

                <p>
                  Choose a program designed around
                  your academic goals.
                </p>
              </div>

              <div className="result-count">
                <strong>
                  {visibleCourses.length}
                </strong>
                <span>Programs</span>
              </div>

            </div>


            <div className="courses-grid">

              {visibleCourses.map((course) => (

                <article
                  className="course-card"
                  key={course.code}
                >

                  <div className="card-image">

                    <img
                      src={course.image}
                      alt={course.title}
                    />

                    <span className={`card-category ${course.type}`}>
                      {course.category}
                    </span>

                    {course.badge && (
                      <span className="card-badge">
                        {course.badge}
                      </span>
                    )}

                  </div>


                  <div className="card-body">

                    <div className="card-heading">

                      <div>

                        <span className="course-code">
                          {course.code}
                        </span>

                        <h3>{course.title}</h3>

                      </div>

                      <div className="course-icon">
                        {course.icon}
                      </div>

                    </div>


                    <p className="card-description">
                      {course.description}
                    </p>


                    <div className="course-info">

                      <div>
                        <Users size={14} />
                        <span>{course.classes}</span>
                      </div>

                      <div>
                        <MonitorPlay size={14} />
                        <span>{course.mode}</span>
                      </div>

                      <div>
                        <Clock3 size={14} />
                        <span>{course.duration}</span>
                      </div>

                    </div>


                    <div className="subject-row">

                      {course.subjects.map(
                        (subject) => (
                          <span key={subject}>
                            {subject}
                          </span>
                        )
                      )}

                    </div>


                    <div className="feature-list">

                      {course.features.map(
                        (feature) => (
                          <span key={feature}>
                            <CheckCircle2 size={13} />
                            {feature}
                          </span>
                        )
                      )}

                    </div>


                    <Link
                      href={course.href}
                      className="explore-button"
                    >
                      Explore Program
                      <ArrowRight size={15} />
                    </Link>

                  </div>

                </article>

              ))}

            </div>


            {visibleCourses.length === 0 && (
              <div className="empty-state">

                <Search size={28} />

                <h3>
                  No courses found
                </h3>

                <p>
                  Try searching for JEE, NEET,
                  IB, IGCSE, SAT or CBSE.
                </p>

                <button
                  onClick={() => {
                    setSearch("");
                    setFilter("all");
                  }}
                >
                  View All Programs
                </button>

              </div>
            )}

          </div>

        </section>


        {/* QUICK CTA */}

        <section className="program-cta">

          <div className="courses-container">

            <div className="cta-box">

              <div className="cta-icon">
                <GraduationCap size={25} />
              </div>

              <div>
                <span>
                  NOT SURE WHAT TO CHOOSE?
                </span>

                <h2>
                  Find the right learning path
                  for your goals.
                </h2>

                <p>
                  Talk to our academic experts and
                  get personalized guidance.
                </p>
              </div>

              <Link
                href="/contact"
                className="cta-button"
              >
                Talk to an Expert
                <ArrowRight size={16} />
              </Link>

            </div>

          </div>

        </section>


        {/* LANGUAGES */}

        <section className="language-section">

          <div className="courses-container">

            <div className="language-inner">

              <div className="language-copy">

                <span>
                  BILINGUAL EXCELLENCE
                </span>

                <h2>
                  Master a Language.
                  <br />
                  <strong>Open a Bigger World.</strong>
                </h2>

                <p>
                  Develop communication skills,
                  confidence and global fluency.
                </p>

                <Link
                  href="/courses/languages"
                >
                  Explore Languages
                  <ArrowRight size={15} />
                </Link>

              </div>


              <div className="language-grid">

                {languages.map((language) => (

                  <div
                    className="language-card"
                    key={language.name}
                  >

                    <div className="language-icon">
                      {language.flag}
                    </div>

                    <div>
                      <h3>{language.name}</h3>

                      <span>
                        {language.subtitle}
                      </span>
                    </div>

                    <p>
                      {language.text}
                    </p>

                    <div>
                      <CheckCircle2 size={13} />
                      Expert-led learning
                    </div>

                  </div>

                ))}

              </div>

            </div>

          </div>

        </section>

      </main>
    </>
  );
}
