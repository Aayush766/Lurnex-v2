import { ProgramPage } from "@/components/courses/ProgramPage";
export default function CoursePage() { return <ProgramPage slug="ib" />; }
