import type { Metadata } from "next";
import { ProgramPage } from "@/components/courses/ProgramPage";
import { siteUrl } from "@/lib/seo";

export const metadata: Metadata = {
  title: "Digital SAT Online Prep & Tutoring | lumex",
  description: "Prepare for the digital SAT with personalised online Math and Reading and Writing tutoring, targeted practice and progress check-ins from lumex.",
  alternates: { canonical: "/courses/sat" },
  openGraph: { title: "Digital SAT Preparation | lumex", description: "Personalised SAT prep with focused practice, study planning and progress guidance.", url: `${siteUrl}/courses/sat`, type: "website" },
};
export default function CoursePage() { return <ProgramPage slug="sat" />; }
