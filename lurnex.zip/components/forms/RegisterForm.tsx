"use client";
import { FormEvent, useState } from "react";
import { courseOptions, gradeOptions } from "@/lib/programs";
import { learningApi } from "@/lib/api";

export function RegisterForm({ initialProgram }: { initialProgram?: string }) {
  const [program, setProgram] = useState(initialProgram?.toUpperCase() === "IGCSE" ? "Cambridge" : initialProgram?.toUpperCase() || "");
  const [status, setStatus] = useState<string | null>(null);
  async function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); setStatus("Submitting your request…"); const values = Object.fromEntries(new FormData(event.currentTarget)); try { const result = await learningApi.registerStudent(values); if (result.token) localStorage.setItem("lumex_token", result.token); setStatus("Thank you — your learning request has been received."); event.currentTarget.reset(); } catch (error) { setStatus(error instanceof Error ? error.message : "Please try again shortly."); } }
  const grades = gradeOptions[program] || gradeOptions.Default;
  return <form onSubmit={submit} className="mt-8 grid gap-4 sm:grid-cols-2"><input required name="studentName" aria-label="Student name" placeholder="Student name" className="rounded-xl border p-3"/><input required name="parentName" aria-label="Parent name" placeholder="Parent name" className="rounded-xl border p-3"/><input required type="email" name="email" aria-label="Email" placeholder="Email address" className="rounded-xl border p-3"/><input required name="mobile" aria-label="Phone number" placeholder="Phone number" className="rounded-xl border p-3"/><select required name="course" value={program} onChange={(event) => setProgram(event.target.value)} className="rounded-xl border bg-white p-3"><option value="">Choose a program</option>{courseOptions.map((course) => <option key={course}>{course}</option>)}</select><select required name="grade" className="rounded-xl border bg-white p-3"><option value="">Choose a grade</option>{grades.map((grade) => <option key={grade}>{grade}</option>)}</select><input name="school" placeholder="School (optional)" className="rounded-xl border p-3 sm:col-span-2"/><button className="rounded-xl bg-[#087FF5] px-5 py-3 font-bold text-white sm:col-span-2">Request a counselling call</button>{status && <p className="text-sm text-slate-600 sm:col-span-2" role="status">{status}</p>}</form>;
}
