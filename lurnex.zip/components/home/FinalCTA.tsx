"use client";

import { FormEvent, useState } from "react";
import {
  Check,
  Send,
  User,
  Mail,
  Phone,
  ArrowRight,
  Sparkles,
  ShieldCheck,
} from "lucide-react";

import "./FinalCTA.css";

type FormStatus = "idle" | "loading" | "success" | "error";

export function FinalCTA() {
  const [status, setStatus] = useState<FormStatus>("idle");

  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    const form = e.currentTarget;

    if (!form.checkValidity()) {
      form.reportValidity();
      setStatus("error");
      return;
    }

    setStatus("loading");

    window.setTimeout(() => {
      setStatus("success");
    }, 700);
  }

  return (
    <section className="final-cta-section">
      <div className="final-cta-container">

        {/* Decorative background */}
        <div className="cta-orb cta-orb-one" />
        <div className="cta-orb cta-orb-two" />
        <div className="cta-grid-pattern" />

        {/* =====================================================
            LEFT SIDE
        ====================================================== */}

        <div className="final-cta-left">

          <div className="final-cta-plane-wrap">
            <div className="final-cta-plane">
              <Send size={39} strokeWidth={1.7} />
            </div>

            <div className="final-cta-spark spark-one">
              <Sparkles size={11} />
            </div>

            <div className="final-cta-spark spark-two">
              <Sparkles size={8} />
            </div>
          </div>

          <div className="final-cta-copy">

            <div className="final-cta-eyebrow">
              <span className="eyebrow-dot" />
              START YOUR JOURNEY
            </div>

            <h2 className="final-cta-title">
              Ready to Start Your
              <span> Learning Journey?</span>
            </h2>

            <p className="final-cta-description">
              Join thousands of students worldwide who are achieving
              their dreams with Lumex.
            </p>

            <div className="final-cta-benefits">

              <div className="cta-benefit">
                <span className="benefit-icon">
                  <Check size={13} strokeWidth={3} />
                </span>
                <span>Free Counselling</span>
              </div>

              <div className="cta-benefit">
                <span className="benefit-icon">
                  <Check size={13} strokeWidth={3} />
                </span>
                <span>Personalised Plan</span>
              </div>

              <div className="cta-benefit">
                <span className="benefit-icon">
                  <Check size={13} strokeWidth={3} />
                </span>
                <span>No Obligation</span>
              </div>

            </div>

          </div>
        </div>


        {/* =====================================================
            FORM CARD
        ====================================================== */}

        <div className="final-cta-form-card">

          <div className="form-card-header">
            <div>
              <h3>Get Started Today</h3>
              <p>Tell us how we can help you.</p>
            </div>

            <div className="secure-badge">
              <ShieldCheck size={14} />
              <span>Secure</span>
            </div>
          </div>


          <form
            className="final-cta-form"
            onSubmit={submit}
          >

            {/* Name */}

            <div className="cta-field">

              <User
                className="cta-field-icon"
                size={17}
                strokeWidth={2}
              />

              <label
                htmlFor="cta-name"
                className="sr-only"
              >
                Full Name
              </label>

              <input
                id="cta-name"
                name="name"
                type="text"
                required
                minLength={2}
                placeholder="Full Name"
              />

            </div>


            {/* Email */}

            <div className="cta-field">

              <Mail
                className="cta-field-icon"
                size={17}
                strokeWidth={2}
              />

              <label
                htmlFor="cta-email"
                className="sr-only"
              >
                Email Address
              </label>

              <input
                id="cta-email"
                name="email"
                type="email"
                required
                placeholder="Email Address"
              />

            </div>


            {/* Phone */}

            <div className="cta-phone-row">

              <div className="cta-country">

                <span className="cta-flag">
                  🇮🇳
                </span>

                <label
                  htmlFor="cta-country"
                  className="sr-only"
                >
                  Country Code
                </label>

                <select
                  id="cta-country"
                  name="country"
                  defaultValue="+91"
                  aria-label="Country code"
                >
                  <option value="+91">+91</option>
                  <option value="+1">+1</option>
                  <option value="+44">+44</option>
                  <option value="+971">+971</option>
                </select>

                <span className="cta-country-chevron">
                  ▾
                </span>

              </div>


              <div className="cta-field cta-mobile-field">

                <Phone
                  className="cta-field-icon"
                  size={17}
                  strokeWidth={2}
                />

                <label
                  htmlFor="cta-phone"
                  className="sr-only"
                >
                  Mobile Number
                </label>

                <input
                  id="cta-phone"
                  name="phone"
                  type="tel"
                  required
                  pattern="[0-9 +()-]{7,}"
                  placeholder="Mobile Number"
                />

              </div>

            </div>


            {/* Submit */}

            <button
              type="submit"
              className="final-cta-submit"
              disabled={status === "loading"}
            >
              <span>
                {status === "loading"
                  ? "Sending..."
                  : status === "success"
                    ? "Request Sent"
                    : "Get Started Now"}
              </span>

              {status !== "loading" && (
                <ArrowRight
                  size={18}
                  strokeWidth={2.7}
                />
              )}

              <span className="button-shine" />
            </button>


            {status === "error" && (
              <p className="final-cta-message error">
                Please complete the required fields with valid details.
              </p>
            )}

            {status === "success" && (
              <p className="final-cta-message success">
                Thanks! Your request is ready to connect to your backend.
              </p>
            )}

          </form>

        </div>


        {/* =====================================================
            RIGHT DECORATION
        ====================================================== */}

        <div className="final-cta-right">

          <div className="future-text">

            <span>Your</span>

            <strong>Future</strong>

            <strong>Starts Here</strong>

          </div>

          <div className="future-arrow">
            ↙
          </div>

        </div>

      </div>
    </section>
  );
}