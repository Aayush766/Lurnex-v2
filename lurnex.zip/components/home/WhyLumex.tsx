import { BarChart3, Crown, Headphones, Users } from "lucide-react";
import type { LucideIcon } from "lucide-react";

const cards: Array<[LucideIcon, string, string]> = [
  [Users, "Expert Global Faculty", "Learn from experienced educators across US, UK, India and more."],
  [Crown, "Personalised Learning", "Customized study plans based on your goals and strengths."],
  [BarChart3, "Proven Results", "Our students get into top universities and colleges worldwide."],
  [Headphones, "End-to-End Support", "From admission guidance to exam prep — we're with you at every step."]
];

export function Whylumex() {
  return (
    <section className="section-pad bg-white">
      <div className="container-shell">
        <div className="text-center">
          <h2 className="text-[24px] font-extrabold text-[#071B3A]">Why Students <span className="text-[#087FF5]">Choose lumex?</span></h2>
          <p className="mt-1 text-xs text-slate-500">More than just classes – we build brighter futures.</p>
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map(([Icon, title, text], i) => (
            <article key={String(title)} className="rounded-lg border border-slate-200 bg-white p-4 shadow-card">
              <span className={`grid h-10 w-10 place-items-center rounded-full ${i===0?"bg-[#E5F1FF] text-[#087FF5]":i===1?"bg-[#FFE7F0] text-[#F06A9B]":i===2?"bg-[#DDF9F6] text-[#10BBD5]":"bg-[#EEE7FF] text-[#6C3BFF]"}`}><Icon size={20}/></span>
              <h3 className="mt-3 text-xs font-extrabold text-[#071B3A]">{title}</h3>
              <p className="mt-1.5 text-[11px] leading-4 text-slate-500">{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
