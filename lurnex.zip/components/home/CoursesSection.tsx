import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { courses } from "@/lib/constants";
import { CourseCard } from "./CourseCard";

export function CoursesSection() {
  return (
    <section id="courses" className="section-pad bg-white">
      <div className="container-shell">
        <div className="mb-4 flex items-end justify-between gap-4">
          <div>
            <h2 className="text-[25px] font-extrabold tracking-tight text-[#071B3A]">Our <span className="text-[#087FF5]">Courses</span></h2>
            <p className="mt-1 text-xs text-slate-500">Expertly crafted programs to ensure your academic excellence.</p>
          </div>
          <Link href="/courses" className="hidden items-center gap-1 rounded-full border border-[#087FF5] px-4 py-2 text-[10px] font-bold text-[#087FF5] sm:flex">View All Courses <ArrowRight size={13}/></Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{courses.map((course) => <CourseCard key={course.href} course={course}/>)}</div>
        <Link href="/courses" className="mx-auto mt-5 flex w-fit items-center gap-1 rounded-full border border-[#087FF5] px-4 py-2 text-[10px] font-bold text-[#087FF5] sm:hidden">View All Courses <ArrowRight size={13}/></Link>
      </div>
    </section>
  );
}
