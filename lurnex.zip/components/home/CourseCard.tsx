import Image from "next/image";
import Link from "next/link";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import type { courses } from "@/lib/constants";

type Course = (typeof courses)[number];

export function CourseCard({ course }: { course: Course }) {
  return (
    <article className="group overflow-hidden rounded-lg border border-slate-200 bg-white shadow-card transition hover:-translate-y-1 hover:shadow-soft">
      <div className="relative aspect-[2.35/1] overflow-hidden">
        {course.badge && <span className="absolute left-3 top-3 z-10 rounded-full bg-[#10BBD5] px-3 py-1 text-[10px] font-bold text-white">{course.badge}</span>}
        <Image src={course.image} alt={course.alt} width={840} height={360} sizes="(max-width: 768px) 100vw, 25vw" className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.02]" />
      </div>
      <div className="p-3.5">
        <h3 className="text-[15px] font-extrabold text-[#071B3A]">{course.title}</h3>
        <p className="mt-0.5 min-h-[37px] text-[11px] leading-4 text-slate-500">{course.description}</p>
        <ul className="mt-2.5 space-y-1.5">
          {course.features.map((f) => <li key={f} className="flex items-center gap-2 text-[11px] text-slate-600"><CheckCircle2 size={13} fill="#168BFF" className="shrink-0 text-white" />{f}</li>)}
        </ul>
        <Link href={course.href} className="mt-3 flex items-center gap-1 border-t border-slate-100 pt-2.5 text-[11px] font-bold text-[#087FF5]">
          Know More <ArrowRight size={13}/>
        </Link>
      </div>
    </article>
  );
}
