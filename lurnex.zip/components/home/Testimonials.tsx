 "use client";

import Image from "next/image";
import { useState } from "react";
import { ChevronLeft, ChevronRight, Quote, Star } from "lucide-react";
import { testimonials } from "@/lib/constants";

export function Testimonials() {
  const [index, setIndex] = useState(0);
  const prev = () => setIndex((i) => (i - 1 + testimonials.length) % testimonials.length);
  const next = () => setIndex((i) => (i + 1) % testimonials.length);

  return (
    <section className="section-pad bg-[#FBFDFF]">
      <div className="container-shell">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-[24px] font-extrabold text-[#071B3A]">What Our <span className="text-[#087FF5]">Learners Say</span></h2>
            <p className="mt-1 text-xs text-slate-500">Real stories. Real success. Real global opportunities.</p>
          </div>
          <div className="flex gap-2">
            <button onClick={prev} aria-label="Previous testimonial" className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 bg-white text-[#071B3A]"><ChevronLeft size={15}/></button>
            <button onClick={next} aria-label="Next testimonial" className="grid h-8 w-8 place-items-center rounded-lg border border-[#087FF5] bg-white text-[#087FF5]"><ChevronRight size={15}/></button>
          </div>
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <article key={t.name} className={`${i === index ? "block" : "hidden md:block"} rounded-lg border border-slate-200 bg-white p-4 shadow-card`}>
              <Quote size={23} className="text-slate-300" fill="currentColor"/>
              <p className="mt-2 min-h-[72px] text-[12px] leading-4.5 text-slate-600">“{t.quote}”</p>
              <div className="mt-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Image src={t.avatar} alt={`${t.name} avatar`} width={40} height={40} className="h-9 w-9 rounded-full object-cover"/>
                  <div><div className="text-[11px] font-extrabold text-[#071B3A]">{t.name}</div><div className="text-[9px] text-slate-400">{t.location}</div></div>
                </div>
                <div className="flex text-[#FFB21A]" aria-label="5 out of 5 stars">{Array.from({length:5}).map((_,s)=><Star key={s} size={12} fill="currentColor"/>)}</div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
