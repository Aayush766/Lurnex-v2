import {
  Globe2,
  UsersRound,
  Trophy,
  Star,
} from "lucide-react";

import "./StatsStrip.css";

type Stat = {
  icon: typeof Globe2;
  top: string;
  bottom: string;
  color: string;
};

const stats: Stat[] = [
  {
    icon: Globe2,
    top: "Students from",
    bottom: "20+ Countries",
    color: "#087FF5",
  },
  {
    icon: UsersRound,
    top: "2,000+",
    bottom: "Hours Taught",
    color: "#7734E8",
  },
  {
    icon: Trophy,
    top: "10+",
    bottom: "Years of Excellence",
    color: "#FFAE16",
  },
  {
    icon: Star,
    top: "4.8/5",
    bottom: "Student Satisfaction",
    color: "#FFAE16",
  },
];

export function StatsStrip() {
  return (
    <section className="stats-strip">
      <div className="stats-container">
        <div className="stats-card">
          {stats.map(
            ({ icon: Icon, top, bottom, color }, index) => (
              <div
                className={`stats-item ${
                  index !== stats.length - 1
                    ? "stats-item-divider"
                    : ""
                }`}
                key={bottom}
              >
                <div
                  className="stats-icon"
                  style={{ color }}
                >
                  <Icon
                    size={44}
                    strokeWidth={1.8}
                  />
                </div>

                <div className="stats-content">
                  <div className="stats-top">
                    {top}
                  </div>

                  <div className="stats-bottom">
                    {bottom}
                  </div>
                </div>
              </div>
            )
          )}
        </div>
      </div>
    </section>
  );
}
