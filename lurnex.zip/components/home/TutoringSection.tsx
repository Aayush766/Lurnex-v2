import Image from "next/image";
import { ArrowRight } from "lucide-react";
import { programs } from "@/lib/constants";

import "./TutoringSection.css";

export function TutoringSection() {
  return (
    <section className="tutoring-section">
      <div className="tutoring-inner">

        {/* ================================================
            LEFT CONTENT
        ================================================= */}

        <div className="tutoring-left">

          <h2 className="tutoring-title">
            One-To-One Live Tutoring
            <br />
            for{" "}
            <span className="tutoring-title-blue">
              Global Programs
            </span>
          </h2>

          <p className="tutoring-description">
            Get expert guidance, personalised learning paths and
            <br />
            doubt resolution – anytime, anywhere.
          </p>

          {/* ==============================================
              ACTIONS + PROGRAMS
          =============================================== */}

          <div className="tutoring-controls">

            {/* Buttons */}
            <div className="tutoring-actions">

              <a
                href="/register"
                className="tutoring-register"
              >
                <span>Register Now</span>

                <ArrowRight
                  size={22}
                  strokeWidth={2.5}
                />
              </a>

              <a
                href="/login"
                className="tutoring-login"
              >
                Login
              </a>

            </div>

            {/* Programs */}
            <div className="tutoring-program-area">

              <div className="tutoring-program-heading">
                CHOOSE YOUR PROGRAM
              </div>

              <div className="tutoring-programs">
                {programs.map((program) => (
                  <span
                    key={program}
                    className="tutoring-program"
                  >
                    {program}
                  </span>
                ))}
              </div>

            </div>
          </div>
        </div>

        {/* ================================================
            RIGHT VISUAL
        ================================================= */}

        <div className="tutoring-right">

          {/* Handwritten message */}
          <div className="tutoring-note">
            Personal
            <br />
            Guidance
            <br />
            Real Growth
          </div>

          {/* Curved arrow */}
          <svg
            className="tutoring-arrow"
            viewBox="0 0 120 100"
            fill="none"
            aria-hidden="true"
          >
            <path
              d="M8 8C10 39 30 58 62 64C82 68 94 76 97 89"
              stroke="#087FF5"
              strokeWidth="3"
              strokeLinecap="round"
            />

            <path
              d="M87 79L98 90L108 80"
              stroke="#087FF5"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>

          {/* Green background decoration */}
          <div className="tutoring-green-shape" />

          {/* Secondary pale blue decoration */}
          <div className="tutoring-blue-shape" />

          {/* Main tutoring image */}
          <Image
            src="/assets/images/ctaimage.png"
            alt="One-to-one live tutoring with Lumex"
            width={1000}
            height={600}
            priority
            sizes="(max-width: 768px) 100vw, 520px"
            className="tutoring-image"
          />

          {/* Small decorative dot */}
          <span className="tutoring-dot tutoring-dot-top" />
          <span className="tutoring-dot tutoring-dot-bottom" />

        </div>
      </div>
    </section>
  );
}
