import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Check,
  GraduationCap,
  Play,
  Trophy,
  Phone,
  Sparkles,
} from "lucide-react";

import "./Hero.css";

const features = [
  {
    text: "Live & Recorded Classes",
    color: "#1684F7",
  },
  {
    text: "Expert Faculty",
    color: "#16B8D0",
  },
  {
    text: "Personalised Learning",
    color: "#1684F7",
  },
  {
    text: "Regular Tests & Analytics",
    color: "#18C6A3",
  },
];

export function Hero() {
  return (
    <section className="hero">
      {/* =====================================================
          BACKGROUND DECORATION
      ====================================================== */}

      <div className="hero-bg" aria-hidden="true">
        <div className="hero-bg-circle hero-bg-circle-left" />
        <div className="hero-bg-circle hero-bg-circle-right" />
        <div className="hero-bg-circle hero-bg-circle-bottom" />
      </div>

      {/* =====================================================
          MAIN HERO CONTAINER
      ====================================================== */}

      <div className="hero-container">
        <div className="hero-grid">

          {/* =================================================
              LEFT CONTENT
          ================================================== */}

          <div className="hero-content">

            {/* Badge */}
            <div className="hero-badge">
              <span className="hero-badge-icon">
                <Sparkles
                  size={9}
                  strokeWidth={3}
                />
              </span>

              <span>GLOBAL LEARNING EXCELLENCE</span>
            </div>

            {/* Heading */}
            <h1 className="hero-title">
              Learn Today,
              <br />
              Build a{" "}
              <span className="hero-gradient-text">
                Brighter Tomorrow
              </span>
            </h1>

            {/* Description */}
            <p className="hero-description">
              Expert-led courses, personalised mentoring and proven results
              for
              <br className="hero-description-break" />
              students across the globe.
            </p>

            {/* Features */}
            <div className="hero-features">
              {features.map((feature) => (
                <div
                  className="hero-feature"
                  key={feature.text}
                >
                  <span
                    className="hero-feature-icon"
                    style={{
                      backgroundColor: feature.color,
                    }}
                  >
                    <Check
                      size={15}
                      strokeWidth={3}
                    />
                  </span>

                  <span className="hero-feature-text">
                    {feature.text}
                  </span>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="hero-actions">

              <Link
                href="/courses"
                className="hero-btn hero-btn-primary"
              >
                <span>Start Learning Now</span>

                <ArrowRight
                  size={19}
                  strokeWidth={2.5}
                />
              </Link>

              <Link
                href="/contact"
                className="hero-btn hero-btn-secondary"
              >
                <Phone
                  size={20}
                  strokeWidth={2.5}
                  fill="#071B41"
                />

                <span>Talk to an Expert</span>
              </Link>

            </div>
          </div>

          {/* =================================================
              CENTER STUDENT
          ================================================== */}

          <div className="hero-visual">

            {/* Background circles */}
            <div className="hero-visual-circle hero-visual-circle-one" />

            <div className="hero-visual-circle hero-visual-circle-two" />

            <div className="hero-visual-circle hero-visual-circle-three" />

            {/* Graduation cap */}
            <div className="hero-graduation-cap">
              <GraduationCap
                size={46}
                strokeWidth={1.5}
              />
            </div>

            {/* Dotted path */}
            <svg
              className="hero-dotted-path"
              viewBox="0 0 180 170"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M15 18C70 0 135 18 148 70C158 111 136 145 105 157"
                stroke="#7CC9FF"
                strokeWidth="2"
                strokeDasharray="6 7"
                strokeLinecap="round"
              />
            </svg>

            {/* Handwritten message */}
            <div className="hero-handwritten">
              Small
              <br />
              Steps
              <br />
              Big Dreams
            </div>

            {/* Curved arrow */}
            <svg
              className="hero-curved-arrow"
              viewBox="0 0 125 105"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M10 8C5 43 31 64 69 67C88 69 99 76 101 91"
                stroke="#087FF5"
                strokeWidth="3"
                strokeLinecap="round"
              />

              <path
                d="M91 81L102 92L113 82"
                stroke="#087FF5"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>

            {/* Floating cyan light */}
            <div className="hero-floating-light">
              <span>✦</span>
            </div>

            {/* Student */}
            <Image
              src="/assets/images/herogirl.png"
              alt="Lumex student learning with books"
              width={880}
              height={880}
              priority
              sizes="(max-width: 1024px) 320px, 370px"
              className="hero-student"
            />
          </div>

          {/* =================================================
              RIGHT STAT CARDS
          ================================================== */}

          <div className="hero-stat-cards">

            {/* Active Students */}
            <div className="hero-stat-card">

              <div className="hero-stat-icon hero-stat-icon-blue">
                <GraduationCap
                  size={45}
                  strokeWidth={1.8}
                />
              </div>

              <div className="hero-stat-content">
                <div className="hero-stat-number">
                  1,300+
                </div>

                <div className="hero-stat-label">
                  Active Students
                </div>
              </div>

            </div>

            {/* Success Rate */}
            <div className="hero-stat-card">

              <div className="hero-stat-icon hero-stat-icon-orange">
                <Trophy
                  size={45}
                  strokeWidth={1.8}
                />
              </div>

              <div className="hero-stat-content">
                <div className="hero-stat-number">
                  95%+
                </div>

                <div className="hero-stat-label">
                  Success Rate
                </div>
              </div>

            </div>

            {/* Live Classes */}
            <div className="hero-stat-card">

              <div className="hero-stat-icon hero-stat-icon-play">
                <Play
                  size={23}
                  fill="white"
                  strokeWidth={1.5}
                />
              </div>

              <div className="hero-stat-content">
                <div className="hero-stat-live-title">
                  Live &amp; Interactive
                </div>

                <div className="hero-stat-live-label">
                  Classes
                </div>
              </div>

            </div>

          </div>
        </div>
      </div>
    </section>
  );
}
