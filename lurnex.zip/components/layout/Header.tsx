"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ChevronDown,
  Menu,
  X,
} from "lucide-react";

import { navItems } from "@/lib/constants";
import { Button } from "@/components/ui/Button";
import { LanguageSelector } from "@/components/ui/LanguageSelector";

// Load the stylesheet without requiring TypeScript module declarations for CSS files.
require("./Header.css");

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">

      {/* =====================================================
          DESKTOP / MAIN HEADER
      ====================================================== */}

      <div className="header-container">

        {/* Logo */}
        <Link
          href="/"
          aria-label="lumex home"
          className="header-logo-link"
        >
          <img
            src="/logo.png"
            alt="lumex"
            className="header-logo"
          />
        </Link>


        {/* =================================================
            DESKTOP NAVIGATION
        ================================================== */}

        <nav
          className="desktop-navigation"
          aria-label="Primary navigation"
        >
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="desktop-nav-link"
            >
              {item.label}
            </Link>
          ))}
        </nav>


        {/* =================================================
            DESKTOP ACTIONS
        ================================================== */}

        <div className="header-actions">

          <LanguageSelector />


          {/* Login */}
          <div className="header-login-button">
            <Button
              href="/login"
              variant="outline"
            >
              Login
            </Button>
          </div>


          {/* Register */}
          <div className="header-register-button">
            <Button href="/register">
              Register
            </Button>
          </div>

        </div>


        {/* =================================================
            MOBILE MENU BUTTON
        ================================================== */}

        <button
          className="mobile-menu-button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={
            open
              ? "Close menu"
              : "Open menu"
          }
          type="button"
        >
          {open ? (
            <X size={21} />
          ) : (
            <Menu size={21} />
          )}
        </button>

      </div>


      {/* ===================================================
          MOBILE NAVIGATION
      ==================================================== */}

      {open && (
        <div
          id="mobile-nav"
          className="mobile-navigation-wrapper"
        >
          <nav
            className="mobile-navigation"
            aria-label="Mobile navigation"
          >

            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="mobile-nav-link"
              >
                {item.label}
              </Link>
            ))}


            {/* Mobile Actions */}
            <div className="mobile-actions">

              <div className="mobile-action-button">
                <Button
                  href="/login"
                  variant="outline"
                >
                  Login
                </Button>
              </div>

              <div className="mobile-action-button">
                <Button href="/register">
                  Register
                </Button>
              </div>

            </div>

          </nav>
        </div>
      )}

    </header>
  );
}
