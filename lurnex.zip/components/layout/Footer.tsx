import Link from "next/link";
import { Facebook, Instagram, Linkedin, Youtube } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="container-shell grid gap-8 py-8 md:grid-cols-[1.3fr_2fr_auto] md:items-center">
        <div>
          <img src="/logo.png" alt="lumex" className="h-11 w-[118px]" />
          <p className="mt-2 text-xs text-slate-500">Learn. Grow. Excel.</p>
        </div>
        <nav className="flex flex-wrap gap-x-7 gap-y-3 text-xs font-medium text-slate-600" aria-label="Footer navigation">
          {[
            ["About Us", "/about"], ["Courses", "/courses"], ["Locations", "/locations"],
            ["Success Stories", "/success-stories"], ["Blog", "/blog"], ["Contact Us", "/contact"]
          ].map(([label, href]) => <Link key={href} href={href} className="hover:text-[#087FF5]">{label}</Link>)}
        </nav>
        <div className="flex gap-3 text-slate-500" aria-label="Social links">
          <Link aria-label="Instagram" href="/social/instagram"><Instagram size={17}/></Link>
          <Link aria-label="YouTube" href="/social/youtube"><Youtube size={17}/></Link>
          <Link aria-label="LinkedIn" href="/social/linkedin"><Linkedin size={17}/></Link>
          <Link aria-label="Facebook" href="/social/facebook"><Facebook size={17}/></Link>
          <Link aria-label="X" href="/social/x" className="text-sm font-bold">X</Link>
        </div>
      </div>
      <div className="bg-[#061D39] text-white">
        <div className="container-shell flex flex-col gap-2 py-3 text-[11px] sm:flex-row sm:items-center sm:justify-between">
          <span>© 2025 lumex. All rights reserved.</span>
          <span className="flex gap-4"><Link href="/privacy">Privacy Policy</Link><span>|</span><Link href="/terms">Terms of Service</Link></span>
        </div>
      </div>
    </footer>
  );
}
